function editDrill(drillID, drillName, drillMessage){
  var element = editDrillContainer;
    element.classList.remove("hidden");
    // Displaying the value
    document.getElementById('editDrill').value = drillMessage;
    document.getElementById('editDrillName').value = drillName;
    document.getElementById('editDrillID').value = drillID;

    var editMessage = editMessageContainer;
    var editBuilding = editBuildingContainer;
    editMessage.classList.add("hidden");
    editBuilding.classList.add("hidden");

    var addDrill = addDrillContainer;
    var addMessage = addMessageContainer;
    var addBuilding = addBuildingContainer;
    addDrill.classList.add("hidden");
    addMessage.classList.add("hidden");
    addBuilding.classList.add("hidden");
}
function editMessage(messageID, messageName, messageMessage){
  var element = editMessageContainer;
    element.classList.remove("hidden");
    // Displaying the value
    document.getElementById("editMessage").value = messageMessage;
    document.getElementById('editMessageID').value = messageID;
    document.getElementById('editMessageName').value = messageName;

    var editDrill = editDrillContainer;
    var editBuilding = editBuildingContainer;
    editDrill.classList.add("hidden");
    editBuilding.classList.add("hidden");

    var addDrill = addDrillContainer;
    var addBuilding = addBuildingContainer;
	 var addMessage = addMessageContainer;
	addBuilding.classList.add("hidden");
    addDrill.classList.add("hidden");
    addMessage.classList.add("hidden");
    
}

function editBuilding(buildingID, buidlingName){
  var element = editBuildingContainer;
    element.classList.remove("hidden");
    // Displaying the value


    document.getElementById("editBuildingID").value = buildingID;
    document.getElementById("currentBuildingID").value = buildingID;
    document.getElementById("editBuildingName").value = buidlingName;

    var editDrill = editDrillContainer;
    var editMessage = editMessageContainer;
    editDrill.classList.add("hidden");
    editMessage.classList.add("hidden");

    var addDrill = addDrillContainer;
    var addMessage = addMessageContainer;
    var addBuilding = addBuildingContainer;
    addDrill.classList.add("hidden");
    addMessage.classList.add("hidden");
    addBuilding.classList.add("hidden");
}


function addDrill(){
  var element = addDrillContainer;
  var message = addMessageContainer;
  var building = addBuildingContainer;
  element.classList.remove("hidden");
  message.classList.add("hidden");
  building.classList.add("hidden");

  var editDrill = editDrillContainer;
  var editMessage = editMessageContainer;
  var editBuilding = editBuildingContainer;
  editDrill.classList.add("hidden");
  editMessage.classList.add("hidden");
  editBuilding.classList.add("hidden");
}
function addMessage(){
  var element = addMessageContainer;
  var drill = addDrillContainer;
  var building = addBuildingContainer;
  element.classList.remove("hidden");
  drill.classList.add("hidden");
  building.classList.add("hidden");

  var editDrill = editDrillContainer;
  var editMessage = editMessageContainer;
  var editBuilding = editBuildingContainer;
  editDrill.classList.add("hidden");
  editMessage.classList.add("hidden");
  editBuilding.classList.add("hidden");
}
function addBuilding(){
  var element = addBuildingContainer;
  var drill = addDrillContainer;
  var message = addMessageContainer;
  element.classList.remove("hidden");
  drill.classList.add("hidden");
  message.classList.add("hidden");

  var editDrill = editDrillContainer;
  var editMessage = editMessageContainer;
  var editBuilding = editBuildingContainer;
  editDrill.classList.add("hidden");
  editMessage.classList.add("hidden");
  editBuilding.classList.add("hidden");
}
