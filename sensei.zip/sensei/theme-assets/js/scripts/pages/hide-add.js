(function($) {
if($(window).width() < 767){
  $("#top-menu-emergency").removeClass("hidden");
  $("#side-menu-emergency").addClass("hidden");
  $("#top-menu-id").addClass("hidden");
  $("#side-menu-id").removeClass("hidden");
}
else{
  $("#top-menu-emergency").addClass("hidden");
  $("#side-menu-emergency").removeClass("hidden");
  $("#top-menu-id").removeClass("hidden");
  $("#side-menu-id").addClass("hidden");
}

})(jQuery);
