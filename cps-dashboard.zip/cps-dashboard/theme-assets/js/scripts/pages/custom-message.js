$(function() {
  $("#message-select").change(function() {
    if ($("#custom-message-select").is(":selected")) {
      $("#custom-message").removeClass("hidden");
      $("#set-message").addClass("hidden");
    } else {
      $("#custom-message").addClass("hidden");
      $("#set-message").removeClass("hidden");
    }
  }).trigger('change');
});
