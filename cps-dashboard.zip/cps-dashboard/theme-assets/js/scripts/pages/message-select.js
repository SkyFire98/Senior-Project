function messageVal() {
  var selectedMessage = document.getElementById("message-select");
  var message = selectedMessage.options[selectedMessage.selectedIndex].value;
  document.getElementById("Messagecomment").value = message;
}
